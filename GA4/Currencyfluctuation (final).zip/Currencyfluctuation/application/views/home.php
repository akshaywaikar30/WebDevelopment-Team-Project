
    <div id="home" class="mt-md col-md-12">
                <div class="col-md-12">
                    <div class="col-md-12 text1 align-center1"><h1>Planning a vacation abroad or a foreign trade?</h1>
                         <h3>We are here to see you through!</h3>
                         <p>Predict the future trends by observing the past fluctuations in currency. Evaluate your own currency with any other foreign currency with our Currency Convertor. Analyze the Fluctuation and invest smartly with our Currency Analyzer. </p>
                    </div>
                    <div class="col-md-12 align-center1">
                        <img src="<?php echo base_url();?>images/index.jpg" height="10%" width="40%">
                    </div>
                    <div class="row">
                        <div class="col-md-6"><h3>Our Mission</h3>
                <ul><li> To demonstrate the currency fluctuations between two currencies.</li>
                    <li> Graphical analysis of the changes in currency in a week or month.</li>
                    <li> To display the record of the lowest and the highest value the currency reached in a particular month.</li>
                </ul></div>
                <div class="col-md-6"><h3>Our Vision</h3>
                <ul><li>To support all the currencies and dynamically update all the values of currencies.</li> 
                    <li>Develop a system to support purchasing any currency via online transaction.</li>
                    <li>To empower the Currency Convertor to calculate the currency exchange rates for all the currencies across the globe.</ul>
                </div>
            </div>
        </div>
            </div>
            <footer id="findex">
            <div class="footer-copyright py-3 text-center bg-dark text-white">
            © 2018 Copyright:
            <a href="<?php echo base_url();?>index.php/currencyConvertor/firstpage"> Currency@Converter.com </a>
        </div>
        <!--/.Copyright-->

    </footer>
            </body>
            </html>
            