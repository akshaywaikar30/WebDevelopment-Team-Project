<div class="main1 col-md-12">
    <div class="mt-md align-center1 text-white">
        <h2 class="align-center1 col-md-12">Welcome to Currency Converter! Choose the appropriate user from below!</h2>
        </div></div>
        <div class="mainbtn">
            <div><a class="btn btn-black col-md-2" href="http://localhost/Currencyfluctuation/index.php/login" id="user"> Users</a></div>
        <div><a class="btn btn-black col-md-2" href="http://localhost/Currencyfluctuation/index.php/admin" id="admin">Admin</a></div>
        </div>
    <footer id="footadmin">
            <div class="footer-copyright py-3 text-center bg-dark text-white">
            © 2018 Copyright:
            <a href="<?php echo base_url();?>index.php/currencyConvertor/firstpage"> Currency@Converter.com </a>
        </div>

    </footer>
    </body>
    </html>